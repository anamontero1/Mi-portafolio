<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'prueba_wordpress');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '|_FPE2uu&!i;A^i/)D$jX:Ca~V$|Y*&8|(2%6z!Xv2|?%7g2^FG(TZ6n6?H&B?l@');
define('SECURE_AUTH_KEY',  '079*@JU7Z2~d9}tKF}|].S/boosuaGJXR!hcYp;Eu$S,yRRPQ*-/]~g &m$I5=a2');
define('LOGGED_IN_KEY',    ',.4I8`N#muK{lwC&ImNVnP*b!oek-;%H307_#fd&Yv*-qN9N=5l3 b^uQ! 4GwXo');
define('NONCE_KEY',        '4L8YUiGug:!X=#&+k[&J|B|ephjQ}B#z1JkY:7zF;8l$^mn%$~ P4Bk1#sINn4kG');
define('AUTH_SALT',        'Rju*]y-OhLK~0?#E6CNcA7I% n?g@{EY,Ea~I)qQ(&ZB~oIT@nM+vs|Mh*:dBhk6');
define('SECURE_AUTH_SALT', '281O7Z]QuXu;haY7d2ZS,pR40,{u l48om-+Wc>]aqlm^aq3JRpF^A-<4qS&mHqR');
define('LOGGED_IN_SALT',   'V/B%~&tEu );uYsI8/;;sRR[_d]NN#:UFnU3Q%ikTlhI6BK/s3!dZW9Ncw/z$l8m');
define('NONCE_SALT',       '~:5c-fxfD4twM(tjqSC,H/5b = 5C@JF0%.Br6gfSN]XG)4cf5/[m#bui(g!u*eg');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
